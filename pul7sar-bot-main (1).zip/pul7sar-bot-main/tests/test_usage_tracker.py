# -*- coding: utf-8 -*-
"""اختبارات usage_tracker.py -- الحصة اليومية، التصفير عند تغيّر التاريخ،
والتعامل الآمن مع ملفات تالفة/غير موجودة."""

import json
import os

import usage_tracker


def test_quota_available_when_no_file(tmp_path, monkeypatch):
    f = tmp_path / "usage.json"
    monkeypatch.setattr(usage_tracker, "USAGE_FILE", str(f))
    assert usage_tracker.has_quota("groq") is True


def test_record_call_increments(tmp_path, monkeypatch):
    f = tmp_path / "usage.json"
    monkeypatch.setattr(usage_tracker, "USAGE_FILE", str(f))
    assert usage_tracker.record_call("gemini") == 1
    assert usage_tracker.record_call("gemini") == 2
    data = json.loads(f.read_text(encoding="utf-8"))
    assert data["counts"]["gemini"] == 2


def test_quota_blocks_after_limit(tmp_path, monkeypatch):
    f = tmp_path / "usage.json"
    monkeypatch.setattr(usage_tracker, "USAGE_FILE", str(f))
    monkeypatch.setitem(usage_tracker.DEFAULT_LIMITS, "google_cse", 2)
    usage_tracker.record_call("google_cse")
    usage_tracker.record_call("google_cse")
    assert usage_tracker.has_quota("google_cse") is False


def test_unknown_service_never_blocked(tmp_path, monkeypatch):
    f = tmp_path / "usage.json"
    monkeypatch.setattr(usage_tracker, "USAGE_FILE", str(f))
    assert usage_tracker.has_quota("some_future_service") is True


def test_resets_on_new_day(tmp_path, monkeypatch):
    f = tmp_path / "usage.json"
    f.write_text(json.dumps({"date": "2000-01-01", "counts": {"groq": 999}}), encoding="utf-8")
    monkeypatch.setattr(usage_tracker, "USAGE_FILE", str(f))
    monkeypatch.setitem(usage_tracker.DEFAULT_LIMITS, "groq", 5)
    # التاريخ المخزَّن قديم -> يُعتبر يوماً جديداً بعداد صفري
    assert usage_tracker.has_quota("groq") is True


def test_corrupted_file_falls_back_to_fresh_counter(tmp_path, monkeypatch):
    f = tmp_path / "usage.json"
    f.write_text("not valid json {{{", encoding="utf-8")
    monkeypatch.setattr(usage_tracker, "USAGE_FILE", str(f))
    assert usage_tracker.has_quota("groq") is True
    assert usage_tracker.record_call("groq") == 1
