# -*- coding: utf-8 -*-
"""اختبارات gemini_vision.py -- تركز على السلوك الآمن-بالفشل (fail-safe) والحارس
الأمني في برومبت توليد الصور، بلا أي نداء شبكة حقيقي (كل شيء يُقلَّد/mocked)."""

import base64
import json
from io import BytesIO
from unittest.mock import patch, MagicMock

from PIL import Image

import gemini_vision


def _dummy_image():
    return Image.new("RGB", (900, 600), (10, 20, 30))


def test_no_api_key_returns_permissive_default(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "")
    result = gemini_vision.judge_image(_dummy_image(), "عنوان", "ملخص", {"player": "Kane"})
    assert result["relevant"] is True
    assert result["foreign_branding"] is False


def test_no_api_key_disables_ai_fallback(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "")
    assert gemini_vision.generate_ai_background({"title": "t"}, {"sport": "football"}) is None


def test_judge_image_parses_rejection(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "fake-key")
    fake_response = {
        "candidates": [{
            "content": {"parts": [{
                "text": json.dumps({
                    "relevant": False,
                    "foreign_branding": True,
                    "visual_temporal_mismatch": False,
                    "reason": "شعار قناة مدموج"
                })
            }]}
        }]
    }
    with patch("gemini_vision._post_gemini", return_value=fake_response):
        result = gemini_vision.judge_image(_dummy_image(), "t", "s", {"club": "Arsenal"})
    assert result["relevant"] is False
    assert result["foreign_branding"] is True


def test_judge_image_rejects_on_visual_temporal_mismatch(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "fake-key")
    fake_response = {
        "candidates": [{
            "content": {"parts": [{
                "text": json.dumps({
                    "relevant": True,
                    "foreign_branding": False,
                    "visual_temporal_mismatch": True,
                    "reason": "اللاعب بقميص ناديه القديم لا الجديد المذكور بالخبر"
                })
            }]}
        }]
    }
    with patch("gemini_vision._post_gemini", return_value=fake_response):
        assert gemini_vision.image_passes_gemini_check(_dummy_image(), {"title": "t"}, {"club": "New Club"}) is False


def test_image_passes_gemini_check_false_on_rejection(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "fake-key")
    with patch("gemini_vision.judge_image", return_value={"relevant": True, "foreign_branding": True, "reason": ""}):
        assert gemini_vision.image_passes_gemini_check(_dummy_image(), {"title": "t"}, {}) is False


def test_judge_image_malformed_json_falls_back_permissive(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "fake-key")
    fake_response = {"candidates": [{"content": {"parts": [{"text": "not json at all"}]}}]}
    with patch("gemini_vision._post_gemini", return_value=fake_response):
        result = gemini_vision.judge_image(_dummy_image(), "t", "s", {})
    assert result["relevant"] is True
    assert result["foreign_branding"] is False


def test_background_prompt_contains_safety_guardrail():
    prompt = gemini_vision._build_background_prompt("خبر تجريبي", {"sport": "football", "club": "Arsenal"})
    assert "Do NOT depict any real, named, or identifiable person" in prompt
    assert "Do NOT include any human face" in prompt
    assert "No text, no logos, no watermarks" in prompt


def test_generate_ai_background_returns_image_on_success(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "fake-key")
    buf = BytesIO()
    _dummy_image().save(buf, format="PNG")
    b64_data = base64.b64encode(buf.getvalue()).decode("ascii")
    fake_response = {
        "candidates": [{
            "content": {"parts": [{"inline_data": {"mime_type": "image/png", "data": b64_data}}]}
        }]
    }
    with patch("gemini_vision._post_gemini", return_value=fake_response):
        img = gemini_vision.generate_ai_background({"title": "t"}, {"sport": "football"})
    assert img is not None
    assert img.size == (900, 600)


def test_generate_ai_background_returns_none_on_missing_image_data(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "fake-key")
    fake_response = {"candidates": [{"content": {"parts": [{"text": "no image here"}]}}]}
    with patch("gemini_vision._post_gemini", return_value=fake_response):
        img = gemini_vision.generate_ai_background({"title": "t"}, {})
    assert img is None


def test_build_ai_placeholder_none_when_background_fails(monkeypatch):
    monkeypatch.setattr(gemini_vision, "generate_ai_background", lambda a, e: None)
    result = gemini_vision.build_ai_placeholder(
        {"title": "خبر"}, {}, "logo_not_exists.png", lambda size: None
    )
    assert result is None


def test_post_gemini_returns_none_without_key(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "")
    assert gemini_vision._post_gemini("gemini-2.5-flash", {}) is None


def test_post_gemini_handles_429(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "fake-key")
    mock_resp = MagicMock(status_code=429)
    with patch("gemini_vision.requests.post", return_value=mock_resp):
        assert gemini_vision._post_gemini("gemini-2.5-flash", {}) is None
