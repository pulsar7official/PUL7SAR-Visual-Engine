# -*- coding: utf-8 -*-
"""اختبارات fact_guard.py -- تركز على السلوك الآمن-بالفشل وصحة تحليل قرارات
الحجب/النشر، بلا أي نداء شبكة حقيقي."""

import json
from unittest.mock import patch, MagicMock

import gemini_vision
import fact_guard


ARTICLE = {"title": "مصدر يقترب من التعاقد مع لاعب", "summary": "تقارير تشير لاحتمال انتقال"}
CONTENT = {"short_post": "رسمياً! انضم اللاعب للنادي الجديد", "long_analysis": "تفاصيل الصفقة المكتملة"}


def test_no_api_key_returns_permissive_publish(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "")
    result = fact_guard.verify_article(ARTICLE, CONTENT, {})
    assert result["verdict"] == "publish"


def test_blocks_on_temporal_inconsistency(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "fake-key")
    fake_response = {
        "candidates": [{
            "content": {"parts": [{
                "text": json.dumps({
                    "temporal_class": "rumor",
                    "temporal_consistent_with_source": False,
                    "hallucinated_claims": [],
                    "entity_mismatches": [],
                    "verdict": "block",
                    "confidence": "high",
                    "reason": "المصدر يذكر احتمالاً بينما المحتوى صاغه كصفقة مؤكدة"
                })
            }]}
        }]
    }
    with patch("gemini_vision._post_gemini", return_value=fake_response):
        result = fact_guard.verify_article(ARTICLE, CONTENT, {"player": "X"})
    assert result["verdict"] == "block"
    assert result["temporal_consistent_with_source"] is False


def test_blocks_on_entity_mismatch(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "fake-key")
    fake_response = {
        "candidates": [{
            "content": {"parts": [{
                "text": json.dumps({
                    "temporal_class": "present",
                    "temporal_consistent_with_source": True,
                    "hallucinated_claims": [],
                    "entity_mismatches": [{"entity": "مدرب", "issue": "يدرب منتخباً حالياً لا النادي المذكور"}],
                    "verdict": "block",
                    "confidence": "medium",
                    "reason": "تعارض في هوية النادي الحالي للمدرب"
                })
            }]}
        }]
    }
    with patch("gemini_vision._post_gemini", return_value=fake_response):
        result = fact_guard.verify_article(ARTICLE, CONTENT, {"club": "Y"})
    assert result["verdict"] == "block"
    assert result["entity_mismatches"]


def test_publishes_on_low_confidence_doubt(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "fake-key")
    fake_response = {
        "candidates": [{
            "content": {"parts": [{
                "text": json.dumps({
                    "temporal_class": "present",
                    "temporal_consistent_with_source": True,
                    "hallucinated_claims": [],
                    "entity_mismatches": [],
                    "verdict": "publish",
                    "confidence": "low",
                    "reason": "لا تعارض واضح"
                })
            }]}
        }]
    }
    with patch("gemini_vision._post_gemini", return_value=fake_response):
        result = fact_guard.verify_article(ARTICLE, CONTENT, {})
    assert result["verdict"] == "publish"


def test_malformed_json_fails_safe_to_publish(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "fake-key")
    fake_response = {"candidates": [{"content": {"parts": [{"text": "ليس JSON"}]}}]}
    with patch("gemini_vision._post_gemini", return_value=fake_response):
        result = fact_guard.verify_article(ARTICLE, CONTENT, {})
    assert result["verdict"] == "publish"


def test_invalid_verdict_value_defaults_to_publish(monkeypatch):
    monkeypatch.setattr(gemini_vision, "GEMINI_API_KEY", "fake-key")
    fake_response = {
        "candidates": [{
            "content": {"parts": [{"text": json.dumps({"verdict": "maybe"})}]}
        }]
    }
    with patch("gemini_vision._post_gemini", return_value=fake_response):
        result = fact_guard.verify_article(ARTICLE, CONTENT, {})
    assert result["verdict"] == "publish"


def test_get_player_current_team_returns_none_on_network_error():
    with patch("fact_guard.requests.get", side_effect=Exception("network down")):
        assert fact_guard.get_player_current_team("Some Player") is None


def test_get_player_current_team_parses_response():
    mock_resp = MagicMock()
    mock_resp.json.return_value = {"player": [{"strTeam": "Real Madrid"}]}
    mock_resp.raise_for_status = lambda: None
    with patch("fact_guard.requests.get", return_value=mock_resp):
        assert fact_guard.get_player_current_team("Some Player") == "Real Madrid"


def test_get_player_current_team_empty_name_returns_none():
    assert fact_guard.get_player_current_team("") is None


def test_get_team_current_manager_returns_none_when_field_missing():
    mock_resp = MagicMock()
    mock_resp.json.return_value = {"teams": [{"strTeam": "Arsenal"}]}
    mock_resp.raise_for_status = lambda: None
    with patch("fact_guard.requests.get", return_value=mock_resp):
        assert fact_guard.get_team_current_manager("Arsenal") is None


def test_gather_evidence_includes_player_and_club(monkeypatch):
    monkeypatch.setattr(fact_guard, "get_player_current_team", lambda name: "Club A")
    monkeypatch.setattr(fact_guard, "get_team_current_manager", lambda name: "Coach B")
    evidence = fact_guard._gather_evidence({"player": "P", "club": "C"})
    assert "Club A" in evidence
    assert "Coach B" in evidence


def test_gather_evidence_empty_when_no_entities():
    evidence = fact_guard._gather_evidence({})
    assert "لا توجد أدلة" in evidence


def test_record_blocked_article_writes_entry(tmp_path, monkeypatch):
    f = tmp_path / "blocked.json"
    monkeypatch.setattr(fact_guard, "BLOCKED_ARTICLES_FILE", str(f))
    verification = {
        "verdict": "block", "confidence": "high", "reason": "تعارض زمني",
        "temporal_class": "rumor", "temporal_consistent_with_source": False,
        "hallucinated_claims": [], "entity_mismatches": [],
    }
    fact_guard.record_blocked_article({"title": "خبر", "link": "https://x"}, verification)
    import json as _json
    data = _json.loads(f.read_text(encoding="utf-8"))
    assert len(data) == 1
    assert data[0]["title"] == "خبر"
    assert data[0]["reason"] == "تعارض زمني"


def test_record_blocked_article_caps_history(tmp_path, monkeypatch):
    f = tmp_path / "blocked.json"
    monkeypatch.setattr(fact_guard, "BLOCKED_ARTICLES_FILE", str(f))
    monkeypatch.setattr(fact_guard, "MAX_BLOCKED_ITEMS", 3)
    for i in range(5):
        fact_guard.record_blocked_article({"title": f"خبر{i}", "link": "x"}, {"verdict": "block"})
    import json as _json
    data = _json.loads(f.read_text(encoding="utf-8"))
    assert len(data) == 3
    assert data[-1]["title"] == "خبر4"


def test_record_blocked_article_recovers_from_corrupted_file(tmp_path, monkeypatch):
    f = tmp_path / "blocked.json"
    f.write_text("not valid json", encoding="utf-8")
    monkeypatch.setattr(fact_guard, "BLOCKED_ARTICLES_FILE", str(f))
    fact_guard.record_blocked_article({"title": "خبر", "link": "x"}, {"verdict": "block"})
    import json as _json
    data = _json.loads(f.read_text(encoding="utf-8"))
    assert len(data) == 1
