# -*- coding: utf-8 -*-
"""
==============================================================================
Fact & Temporal Consistency Guard — نظام حماية من الهلوسة والأخطاء الواقعية/الزمنية
==============================================================================
طبقة تحقق مستقلة تُشغَّل بعد توليد المحتوى (Groq) وقبل النشر مباشرة. تعالج 3
فئات أخطاء حقيقية يمكن أن ينتجها نموذج توليدي حتى لو كانت لغته سليمة 100%
(طبقات 1-7 الحالية تتحقق من سلامة *اللغة* فقط، لا من *صحة الوقائع*):

  1) الهلوسة الواقعية (Hallucination): أرقام/تصريحات/تفاصيل يخترعها النموذج
     ولا وجود لها في النص المصدر (RSS) أصلاً.

  2) عدم الاتساق الزمني (Temporal drift): المصدر يصف الخبر كاحتمال/ترشيح/شائعة
     ("قد ينضم"، "مهتم بالتعاقد") لكن الصياغة المولَّدة ترفعه لدرجة يقين
     ("انضم رسمياً") -- تضخيم يقين شائع في التلخيص الآلي.

  3) تعارض الكيانات مع الواقع الحالي: أخطر مثال واقعي واجهه المستخدم -- خبر
     يصف مدرباً بأنه "مدرب نادي X" بينما هو حالياً يدرب منتخباً مختلفاً (أو
     العكس)، أو لاعباً "من نادي Y" بينما انتقل بالفعل لناديٍ آخر. المصدر
     الإخباري نفسه قد يكون قديم الصياغة أو معاد نشره بأسلوب مضلّل.

الاستراتيجية: تجميع أدلة خارجية موثّقة (TheSportsDB) عند توفرها كـ"حقيقة
أرضية" (ground truth) تُرفَق مع النص المصدر، ثم طلب حكم واحد شامل من Gemini
بصيغة JSON صارمة. عند أي تعارض واضح (لا شك بسيط) بين المحتوى المولَّد وبين
المصدر/الأدلة الخارجية -> verdict="block" ولا يُنشر الخبر إطلاقاً.

فلسفة "آمن-بالفشل" نفسها المتبعة في gemini_vision.py: أي خطأ شبكة/مفتاح مفقود
يُعيد verdict="publish" (لا نحجب النشر بسبب تعطّل خدمة خارجية) -- هذه طبقة
حماية إضافية فوق النظام الحالي، وليست بديلاً عنه أو نقطة فشل وحيدة (SPOF).
"""

import json
import logging
import os
import re
from datetime import datetime, timezone
from urllib.parse import quote

import requests

import gemini_vision

LOG = logging.getLogger("pul7sar.fact_guard")

THESPORTSDB_API_KEY = "3"
HTTP_TIMEOUT = 10

BLOCKED_ARTICLES_FILE = os.environ.get("BLOCKED_ARTICLES_FILE", "blocked_articles.json")
MAX_BLOCKED_ITEMS = 200

_DEFAULT_RESULT = {
    "temporal_class": "unknown",
    "temporal_consistent_with_source": True,
    "hallucinated_claims": [],
    "entity_mismatches": [],
    "verdict": "publish",
    "confidence": "low",
    "reason": "fact_guard_unavailable",
}


# ==============================================================================
# أدلة خارجية موثّقة (Ground Truth) من TheSportsDB -- نفس المفتاح المجاني
# المستخدم أصلاً في main.py لجلب صور اللاعبين/الأندية.
# ==============================================================================

def get_player_current_team(player_name: str):
    """
    يعيد اسم النادي الحالي المسجّل للاعب في TheSportsDB (حقل strTeam)، أو None
    عند عدم العثور عليه أو أي خطأ شبكة. هذا دليل خارجي حقيقي -- أدق بكثير من
    الاعتماد فقط على ذاكرة نموذج لغوي قد تكون معلوماته قديمة هي الأخرى.
    ملاحظة أمانة: تغطية TheSportsDB للاعبين أقل شهرة قد تكون ناقصة أو غير
    محدّثة فوراً بعد صفقة انتقال حديثة جداً -- استخدمه كدليل داعم لا حقيقة مطلقة.
    """
    if not player_name:
        return None
    try:
        url = f"https://www.thesportsdb.com/api/v1/json/{THESPORTSDB_API_KEY}/searchplayers.php?p={quote(player_name)}"
        r = requests.get(url, timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        players = r.json().get("player") or []
        if players:
            return players[0].get("strTeam")
    except Exception as e:
        LOG.info("تعذّر جلب النادي الحالي للاعب '%s' من TheSportsDB: %s", player_name, e)
    return None


def get_team_current_manager(team_name: str):
    """
    محاولة أفضل-جهد (best-effort) لجلب اسم المدرب الحالي لنادٍ من TheSportsDB.
    تنبيه أمانة صريح: حقل المدرب (strManager) ليس مضموناً في كل استجابات
    الفئة المجانية من TheSportsDB وقد يكون فارغاً/غير محدَّث لفرق كثيرة --
    لذلك هذه الدالة *داعمة فقط*؛ الفحص الأساسي لتناقضات المدربين يعتمد على
    معرفة Gemini نفسه مع الإشارة صراحة لمستوى الثقة الأقل في هذه الحالة
    (راجع البرومبت أدناه -- "confidence" ينخفض تلقائياً بلا دليل خارجي مؤكد).
    """
    if not team_name:
        return None
    try:
        url = f"https://www.thesportsdb.com/api/v1/json/{THESPORTSDB_API_KEY}/searchteams.php?t={quote(team_name)}"
        r = requests.get(url, timeout=HTTP_TIMEOUT)
        r.raise_for_status()
        teams = r.json().get("teams") or []
        if teams:
            manager = teams[0].get("strManager")
            return manager or None
    except Exception as e:
        LOG.info("تعذّر جلب مدرب النادي '%s' من TheSportsDB: %s", team_name, e)
    return None


def _gather_evidence(entities: dict) -> str:
    lines = []
    player = entities.get("player")
    club = entities.get("club")

    if player:
        current_team = get_player_current_team(player)
        if current_team:
            lines.append(f"- اللاعب '{player}': ناديه الحالي المسجَّل في قاعدة بيانات رياضية خارجية هو '{current_team}'.")

    if club:
        manager = get_team_current_manager(club)
        if manager:
            lines.append(f"- نادي '{club}': مدربه الحالي المسجَّل في قاعدة بيانات رياضية خارجية هو '{manager}'.")

    return "\n".join(lines) if lines else "لا توجد أدلة خارجية موثّقة متاحة لهذا الخبر."


# ==============================================================================
# الحكم الشامل عبر Gemini
# ==============================================================================

def verify_article(article: dict, generated_content: dict, entities: dict) -> dict:
    """
    يفحص المحتوى المولَّد (short_post + long_analysis) مقابل النص المصدر
    (RSS -- الحقيقة المرجعية الوحيدة لمحتوى الخبر نفسه) + أي أدلة خارجية
    متاحة، ويعيد حكماً بصيغة dict. عند فشل/تعطّل Gemini يعيد نتيجة متساهلة
    (verdict="publish") حتى لا تصبح هذه الطبقة نقطة فشل وحيدة تعطّل البوت.
    """
    if not gemini_vision.GEMINI_API_KEY:
        return dict(_DEFAULT_RESULT)

    evidence = _gather_evidence(entities)
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    prompt = (
        "أنت نظام تحقق واقعي وزمني صارم لمنصة أخبار رياضية آلية (PUL7SAR). "
        "مهمتك حماية المنصة من نشر معلومة مضلّلة أو مختلَقة أو منتهية الصلاحية زمنياً.\n\n"
        f"تاريخ اليوم: {today}\n\n"
        "النص المصدر (RSS) — هو المرجع الوحيد لوقائع هذا الخبر تحديداً، لا تفترض أي تفصيل غير مذكور فيه صراحة:\n"
        f"العنوان: {article.get('title', '')}\n"
        f"الملخص: {article.get('summary', '')}\n\n"
        "المحتوى المُولَّد آلياً (Groq) والمطلوب فحصه قبل النشر:\n"
        f"الخبر المختصر: {generated_content.get('short_post', '')}\n"
        f"التحليل المطوّل: {generated_content.get('long_analysis', '')}\n\n"
        f"أدلة خارجية موثّقة إضافية (قاعدة بيانات رياضية، إن وُجدت):\n{evidence}\n\n"
        "افحص بدقة شديدة وأعد ردك بصيغة JSON صحيحة فقط (بلا أي نص أو ماركداون خارج الأقواس)، بالشكل التالي بالضبط:\n"
        "{\n"
        '  "temporal_class": "past" أو "ongoing" أو "future_expected" أو "rumor",\n'
        '  "temporal_consistent_with_source": true أو false — هل درجة اليقين في المحتوى المولَّد (مؤكد/محتمل/شائعة) تطابق درجة يقين المصدر نفسه؟\n'
        '  "hallucinated_claims": ["أي رقم/تصريح/تفصيل ورد بالمحتوى المولَّد ولا وجود له إطلاقاً في المصدر"],\n'
        '  "entity_mismatches": [{"entity": "اسم اللاعب/المدرب/النادي", "issue": "وصف التعارض مع الأدلة الخارجية أو معرفتك الحالية"}],\n'
        '  "verdict": "publish" أو "block",\n'
        '  "confidence": "high" أو "medium" أو "low",\n'
        '  "reason": "جملة قصيرة توضح سبب القرار"\n'
        "}\n\n"
        "قواعد الحكم الصارمة:\n"
        "- لو المصدر يصف الخبر بلغة احتمال/ترشيح/تكهن (مثل: قد، يُحتمل، مهتم بالتعاقد، اقتراب) "
        "والمحتوى المولَّد صاغه كصفقة/واقعة مؤكدة ومنجزة بالفعل -> temporal_consistent_with_source=false و verdict=block.\n"
        "- لو ذُكر لاعب أو مدرب بصفة (ناديه الحالي/الفريق الذي يدربه الآن) تتعارض بوضوح مع دليل خارجي موثّق أعلاه، "
        "أو مع معرفتك الحالية الراسخة (مثل مدرب انتقل لتدريب منتخب وطني ولم يعد يدرب ناديه السابق) -> "
        "أضِفه لـentity_mismatches و verdict=block.\n"
        "- لو فيه رقم/اقتباس/تفصيل جوهري (يغيّر فهم القارئ للخبر) غير موجود بالمصدر إطلاقاً -> block. "
        "لو الإضافة تجميلية بحتة (هاشتاق، صياغة، إيموجي) فلا تُعتبر هلوسة ولا تمنع النشر.\n"
        "- عند شك بسيط أو غياب أي دليل قاطع للنفي أو الإثبات -> verdict=publish مع confidence=low "
        "(لا نحجب خبراً بسبب الشك وحده، فقط عند تعارض واضح وصريح).\n"
    )

    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.1, "responseMimeType": "application/json"},
    }

    response = gemini_vision._post_gemini(gemini_vision.GEMINI_VISION_MODEL, payload)
    if not response:
        return dict(_DEFAULT_RESULT)

    raw_text = gemini_vision._extract_text(response)
    if not raw_text:
        return dict(_DEFAULT_RESULT)

    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw_text.strip(), flags=re.MULTILINE).strip()
    try:
        data = json.loads(cleaned)
    except (json.JSONDecodeError, TypeError):
        LOG.warning("⚠️ Fact Guard: رد Gemini غير صالح كـJSON -- سيُنشر الخبر افتراضياً (fail-safe)")
        return dict(_DEFAULT_RESULT)

    result = {
        "temporal_class": str(data.get("temporal_class", "unknown")),
        "temporal_consistent_with_source": bool(data.get("temporal_consistent_with_source", True)),
        "hallucinated_claims": list(data.get("hallucinated_claims") or []),
        "entity_mismatches": list(data.get("entity_mismatches") or []),
        "verdict": data.get("verdict") if data.get("verdict") in ("publish", "block") else "publish",
        "confidence": data.get("confidence", "low"),
        "reason": str(data.get("reason", ""))[:300],
    }

    if result["verdict"] == "block":
        LOG.warning(
            "🚫 Fact Guard حجب الخبر | زمني_متسق=%s | كيانات_متعارضة=%s | هلوسات=%s | سبب=%s",
            result["temporal_consistent_with_source"], result["entity_mismatches"],
            result["hallucinated_claims"], result["reason"],
        )
    return result


def record_blocked_article(article: dict, verification: dict):
    """
    يحفظ كل خبر حجبه fact_guard في blocked_articles.json للمراجعة الدورية
    اليدوية -- بلا هذا السجل، الخبر المحجوب يضيع تماماً ويظهر فقط بسطر واحد
    في الـlog (اللي غالباً بيُمسح بعد انتهاء تشغيلة GitHub Actions). المراجعة
    الدورية مهمة لاكتشاف "false positives" (أخبار صحيحة حُجبت غلط) وتعديل
    البرومبت أو الأدلة الخارجية بناءً عليها.
    """
    entry = {
        "title": article.get("title", ""),
        "link": article.get("link", ""),
        "blocked_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "verdict": verification.get("verdict"),
        "confidence": verification.get("confidence"),
        "reason": verification.get("reason", ""),
        "temporal_class": verification.get("temporal_class"),
        "temporal_consistent_with_source": verification.get("temporal_consistent_with_source"),
        "hallucinated_claims": verification.get("hallucinated_claims", []),
        "entity_mismatches": verification.get("entity_mismatches", []),
    }

    data = []
    if os.path.exists(BLOCKED_ARTICLES_FILE):
        try:
            with open(BLOCKED_ARTICLES_FILE, "r", encoding="utf-8") as f:
                loaded = json.load(f)
            if isinstance(loaded, list):
                data = loaded
        except (json.JSONDecodeError, OSError) as exc:
            LOG.warning("تعذّر قراءة سجل الأخبار المحجوبة، سيبدأ سجل جديد: %s", exc)

    data.append(entry)
    data = data[-MAX_BLOCKED_ITEMS:]

    try:
        with open(BLOCKED_ARTICLES_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError as exc:
        LOG.warning("تعذّر حفظ سجل الأخبار المحجوبة: %s", exc)
