from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw

from engine.bootstrap import create_engine
from engine.integration.article_adapter import render_article_with_engine


def make_sample_image() -> Image.Image:
    width, height = 1600, 1000
    image = Image.new("RGB", (width, height), (16, 33, 52))
    draw = ImageDraw.Draw(image)

    for y in range(height):
        t = y / max(1, height - 1)
        draw.line(
            (0, y, width, y),
            fill=(int(15 + 10 * t), int(28 + 60 * t), int(55 + 20 * t)),
        )

    draw.rectangle((0, 620, width, height), fill=(24, 78, 55))
    draw.line((0, 810, width, 810), fill=(220, 230, 230), width=5)
    draw.ellipse((600, 650, 1000, 970), outline=(220, 230, 230), width=5)

    for x in (160, 1340):
        draw.ellipse((x - 90, 100, x + 90, 280), fill=(120, 175, 255))
        draw.ellipse((x - 45, 145, x + 45, 235), fill=(235, 245, 255))

    return image

PREVIEWS = (
    ("default", None),
    ("real_madrid", "real_madrid"),
    ("barcelona", "barcelona"),
    ("chelsea", "chelsea"),
    ("liverpool", "liverpool"),
)


def main() -> None:
    article = {
        "title": "ريال مدريد يحسم المواجهة بثلاثية ويواصل صدارة الدوري",
        "summary": "",
    }
    sample = make_sample_image()
    engine = create_engine()

    print("Generating previews:")
    for name, entity in PREVIEWS:
        result = render_article_with_engine(
            article,
            engine=engine,
            selected_image=sample,
            entity=entity,
        )
        path = Path(__file__).with_name(f"preview_{name}.jpg")
        path.write_bytes(result)
        with Image.open(path) as image:
            print(
                f"  {name}: {path.name} | "
                f"{image.format} {image.size} {image.mode} "
                f"{path.stat().st_size} bytes"
            )


if __name__ == "__main__":
    main()
