# -*- coding: utf-8 -*-
"""
==============================================================================
وحدة Gemini Vision — تحقق بصري من الصور + توليد خلفيات احتياطية آمنة
==============================================================================
هذه الوحدة منفصلة تماماً عن main.py لسهولة الاختبار والصيانة، وتُستدعى منه فقط.

تحل هذه الوحدة 3 مشاكل حقيقية اشتكى منها المستخدم في نظام جلب الصور الحالي:

  1) صور فيها لوجوهات منصات/قنوات أخرى مدمجة (لا يكفي استبعاد نطاقات بعينها
     مثل bbci.co.uk أو skysports.com -- أي مصدر جديد قد يحمل نفس المشكلة).
  2) لا توجد صورة حقيقية مناسبة للخبر إطلاقاً في أي مصدر.
  3) الصور المختارة أحياناً غير مطابقة فعلياً لمحتوى الخبر رغم اجتيازها
     التحقق النصي (is_candidate_relevant) لأن ذلك التحقق نصي بحت ولا "يرى"
     الصورة نفسها.

القيد الهندسي الثابت الذي لا يُفتح للنقاش (راجع الذاكرة/القرارات السابقة):
  ممنوع تماماً توليد صور فوتوريالستيك لأشخاص حقيقيين محددين (لاعبين/مدربين/
  مسؤولين بالاسم والملامح) أو تركيبهم في مشاهد/اقتباسات لم تحدث فعلاً --
  يُعتبر ذلك محتوى مضلّلاً (deepfake) بغض النظر عن نية الاستخدام. لذلك دالة
  generate_fallback_background() تولّد **خلفية عامة/تجريدية بلا وجه بشري
  محدد إطلاقاً** (أجواء استاد، إضاءة، ملعب، جزيئات) ثم يُكتب اسم اللاعب/الخبر
  كنص فوقها -- تماماً بنفس فلسفة build_placeholder_professional() الحالية،
  لكن بخلفية مولّدة بجودة أعلى بدل التدرج اللوني الثابت.

كل الدوال هنا "آمنة بالفشل" (fail-safe): أي خطأ شبكة/مفتاح مفقود/JSON غير
صالح يُعيد None فقط، ولا يوقف نشر الخبر أبداً -- المستدعي (main.py) دائماً
لديه مسار احتياطي (البطاقة الثابتة القديمة) عند فشل أي دالة هنا.
"""

import base64
import json
import logging
import os
import re
from io import BytesIO

import requests
from PIL import Image, ImageDraw

import usage_tracker

LOG = logging.getLogger("pul7sar.gemini")

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "").strip()
GEMINI_API_BASE = "https://generativelanguage.googleapis.com/v1beta/models"

# نموذج الرؤية/التحقق النصي (رخيص وسريع، فيه Free Tier سخي يكفي بوتاً يعمل
# كل ساعة بمسافة كبيرة -- راجع حدود Google الرسمية عند الإعداد).
GEMINI_VISION_MODEL = os.environ.get("GEMINI_VISION_MODEL", "gemini-2.5-flash").strip()

# نموذج توليد الصور (Nano Banana). أيضاً له Free Tier عبر مفتاح API مباشر.
GEMINI_IMAGE_MODEL = os.environ.get("GEMINI_IMAGE_MODEL", "gemini-2.5-flash-image").strip()

HTTP_TIMEOUT = 30


def _b64_image(img: Image.Image, fmt: str = "JPEG") -> str:
    buf = BytesIO()
    img.convert("RGB").save(buf, format=fmt, quality=90)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _post_gemini(model: str, payload: dict):
    """نداء REST خام إلى Gemini API. يعيد dict الاستجابة أو None عند أي فشل."""
    if not GEMINI_API_KEY:
        LOG.info("🔒 GEMINI_API_KEY غير مضبوط -- تخطي ميزات Gemini")
        return None
    if not usage_tracker.has_quota("gemini"):
        return None
    url = f"{GEMINI_API_BASE}/{model}:generateContent?key={GEMINI_API_KEY}"
    try:
        usage_tracker.record_call("gemini")
        r = requests.post(url, json=payload, timeout=HTTP_TIMEOUT)
        if r.status_code == 429:
            LOG.warning("⏳ Gemini: تجاوز الحد المجاني اليومي/الدقيقة (429) -- تخطي هذه المرة")
            return None
        r.raise_for_status()
        return r.json()
    except Exception as e:
        LOG.warning("⚠️ فشل نداء Gemini (%s): %s", model, e)
        return None


def _extract_text(response: dict):
    try:
        parts = response["candidates"][0]["content"]["parts"]
        for p in parts:
            if "text" in p:
                return p["text"]
    except (KeyError, IndexError, TypeError):
        pass
    return None


def _extract_inline_image(response: dict):
    try:
        parts = response["candidates"][0]["content"]["parts"]
        for p in parts:
            inline = p.get("inlineData") or p.get("inline_data")
            if inline and inline.get("data"):
                raw = base64.b64decode(inline["data"])
                return Image.open(BytesIO(raw)).convert("RGB")
    except (KeyError, IndexError, TypeError, ValueError) as e:
        LOG.warning("⚠️ فشل استخراج صورة من رد Gemini: %s", e)
    return None


# ==============================================================================
# 1) و 3) قاضي الصلة البصرية + كاشف اللوجوهات/العلامات المدمجة
# ==============================================================================

def judge_image(img: Image.Image, article_title: str, article_summary: str, entities: dict) -> dict:
    """
    يبعث الصورة المرشّحة فعلياً (لا نصها فقط) لـGemini مع نص الخبر، ويطلب حكماً
    بصرياً حقيقياً بصيغة JSON صارمة. هذا يغطي فجوتين معاً:
      - "foreign_branding": فيه شعار/اسم قناة أو منصة أخرى مطبوع على الصورة نفسها
        (بديل أعم من استبعاد نطاقات بعينها -- يكتشف أي مصدر جديد بنفس المشكلة).
      - "relevant": هل محتوى الصورة فعلاً يطابق موضوع الخبر (لاعب/نادٍ/رياضة)،
        وليس فقط تطابق كلمات في عنوان النتيجة.

    عند أي فشل (لا مفتاح/خطأ شبكة/JSON غير صالح) تُعاد نتيجة متساهلة افتراضياً
    (relevant=True, foreign_branding=False) حتى لا نعطّل نظام الصور الحالي --
    هذه الميزة إضافة فوق التحقق النصي الموجود، وليست بديلاً يُسقط الصورة بمفرده
    عند تعطّل الشبكة.
    """
    default = {"relevant": True, "foreign_branding": False, "visual_temporal_mismatch": False, "reason": "gemini_unavailable"}

    if not GEMINI_API_KEY:
        return default

    entity_desc = ", ".join(
        f"{k}={v}" for k, v in entities.items() if v and k in ("player", "club", "sport")
    ) or "غير محدد"

    prompt = (
        "أنت مدقق صور لمنصة أخبار رياضية. سأعطيك صورة مرشحة ليتم نشرها مع خبر رياضي.\n"
        f"عنوان الخبر: {article_title}\n"
        f"ملخص الخبر: {(article_summary or '')[:400]}\n"
        f"الكيانات المستخرجة من الخبر: {entity_desc}\n\n"
        "افحص الصورة وأجب بصيغة JSON صحيحة فقط (بلا أي نص أو ماركداون خارج الأقواس)، بالشكل التالي بالضبط:\n"
        "{\n"
        '  "relevant": true أو false — هل محتوى الصورة فعلياً يطابق لاعب/نادٍ/رياضة الخبر أعلاه؟\n'
        '  "foreign_branding": true أو false — هل يوجد شعار قناة/موقع إخباري/منصة أخرى مطبوع أو مدموج داخل الصورة نفسها؟\n'
        '  "visual_temporal_mismatch": true أو false — هل تُظهر الصورة اللاعب/المدرب بقميص أو شعار نادٍ '
        "أو منتخب *مختلف* عن الكيانات المذكورة أعلاه (مثال حقيقي شائع: خبر عن انتقال لاعب لناديه الجديد، "
        "لكن الصورة المتاحة له لا تزال بقميص ناديه القديم)؟ اعتبرها true أيضاً لو الصورة واضح من سياقها "
        "(ملعب/جمهور/لافتات) أنها من حدث أو موسم مختلف تماماً عن سياق الخبر الحالي.\n"
        '  "reason": "جملة قصيرة توضح سبب القرار"\n'
        "}"
    )

    payload = {
        "contents": [{
            "parts": [
                {"text": prompt},
                {"inline_data": {"mime_type": "image/jpeg", "data": _b64_image(img)}},
            ]
        }],
        "generationConfig": {"temperature": 0.1, "responseMimeType": "application/json"},
    }

    response = _post_gemini(GEMINI_VISION_MODEL, payload)
    if not response:
        return default

    raw_text = _extract_text(response)
    if not raw_text:
        return default

    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw_text.strip(), flags=re.MULTILINE).strip()
    try:
        data = json.loads(cleaned)
    except (json.JSONDecodeError, TypeError):
        LOG.warning("⚠️ Gemini: رد غير صالح كـJSON لتحقق الصورة")
        return default

    result = {
        "relevant": bool(data.get("relevant", True)),
        "foreign_branding": bool(data.get("foreign_branding", False)),
        "visual_temporal_mismatch": bool(data.get("visual_temporal_mismatch", False)),
        "reason": str(data.get("reason", ""))[:200],
    }
    if not result["relevant"] or result["foreign_branding"] or result["visual_temporal_mismatch"]:
        LOG.info("🚫 Gemini رفض الصورة: relevant=%s foreign_branding=%s temporal_mismatch=%s سبب=%s",
                  result["relevant"], result["foreign_branding"], result["visual_temporal_mismatch"], result["reason"])
    return result


def image_passes_gemini_check(img: Image.Image, article: dict, entities: dict) -> bool:
    """واجهة مبسّطة تُستخدم مباشرة داخل حلقة اختيار الصور في main.py."""
    result = judge_image(
        img,
        article.get("title", ""),
        article.get("summary", ""),
        entities,
    )
    return result["relevant"] and not result["foreign_branding"] and not result.get("visual_temporal_mismatch", False)


# ==============================================================================
# 2) توليد خلفية احتياطية آمنة (بلا أي وجه بشري حقيقي) عبر Gemini Image
# ==============================================================================

# نص الحارس (guardrail) يُضاف لكل برومبت توليد صورة بلا استثناء -- الهدف منع
# النموذج من محاولة تخمين/تركيب ملامح شخص حقيقي حتى لو ذُكر اسمه ضمن السياق.
_SAFETY_GUARDRAIL = (
    "Do NOT depict any real, named, or identifiable person. "
    "Do NOT include any human face or recognizable human figure at all. "
    "No text, no logos, no watermarks, no captions inside the image. "
    "Purely abstract/atmospheric sports scenery only."
)


def _build_background_prompt(article_title: str, entities: dict) -> str:
    sport = entities.get("sport") or "football"
    club = entities.get("club")

    scene = f"a premium {sport} stadium atmosphere at night"
    if club:
        # اسم النادي يُستخدم فقط كإشارة لونية/أجواء (لون الفريق) -- ليس لتصوير
        # لاعبيه أو شعاره الحقيقي (حقوق ملكية + منع أي إيحاء بتمثيل حدث فعلي).
        scene += f", inspired by the general mood of a top-tier club match (no real logos, no real players)"

    return (
        f"Create a cinematic, abstract sports background image representing: {scene}. "
        "Dark charcoal background, electric blue (#0070FF) dynamic lighting and light streaks, "
        "subtle floodlight glow, atmospheric dust/particles, motion blur suggesting speed and energy, "
        "empty foreground area in the lower-center third suitable for adding text later. "
        "Premium, modern, minimal, broadcast-quality look. "
        f"{_SAFETY_GUARDRAIL}"
    )


def generate_ai_background(article: dict, entities: dict):
    """
    يولّد خلفية عامة/تجريدية (1280x720 تقريباً بعد المعالجة) عبر Gemini Image،
    بلا أي وجه بشري أو تمثيل لشخص حقيقي -- راجع _SAFETY_GUARDRAIL. تُستخدم فقط
    كبديل أرقى من build_placeholder_professional() الثابتة، وليست بديلاً عن
    صورة حقيقية موثّقة (التي تبقى الخيار الأول دائماً في get_best_image_for_article).

    تعيد PIL.Image عند النجاح، أو None عند أي فشل (لا مفتاح/حصة منتهية/خطأ) --
    عندها يستخدم main.py البطاقة الثابتة القديمة كما كان قبل هذه الميزة تماماً.
    """
    if not GEMINI_API_KEY:
        return None

    prompt = _build_background_prompt(article.get("title", ""), entities)
    payload = {"contents": [{"parts": [{"text": prompt}]}]}

    response = _post_gemini(GEMINI_IMAGE_MODEL, payload)
    if not response:
        return None

    img = _extract_inline_image(response)
    if img is None:
        LOG.warning("⚠️ Gemini Image: لم تُعَد أي بيانات صورة صالحة")
        return None

    LOG.info("✅ تم توليد خلفية احتياطية عبر Gemini (%dx%d)", img.size[0], img.size[1])
    return img


def build_ai_placeholder(article: dict, entities: dict, logo_path: str, load_font_fn, overlay_texts: bool = True):
    """
    يبني البطاقة الاحتياطية الكاملة: خلفية مولّدة من generate_ai_background()
    + نفس عناصر الهوية (الشعار، عنوان النادي/اللاعب كنص) التي كانت تُرسم يدوياً
    فوق التدرج اللوني الثابت في build_placeholder_professional(). لو فشل توليد
    الخلفية تُعاد None، ليستخدم main.py البطاقة الثابتة القديمة كمسار احتياطي
    أخير (المسار لم يتغير، فقط أُضيف مسار جديد أفضل قبله).
    """
    bg = generate_ai_background(article, entities)
    if bg is None:
        return None

    canvas = bg.resize((1280, 720), Image.Resampling.LANCZOS).convert("RGB")

    if overlay_texts:
        draw = ImageDraw.Draw(canvas, "RGBA")
        # شريط شبه شفاف أسفل الصورة لضمان وضوح النص مهما كانت الخلفية
        draw.rectangle([(0, 520), (1280, 720)], fill=(10, 12, 18, 150))

        title = (article.get("title") or "").strip()
        if title:
            font_title = load_font_fn(34)
            # اقتطاع بسيط لعنوان طويل جداً كي لا يخرج عن حدود القماشة
            display_title = title if len(title) <= 70 else title[:67].rstrip() + "..."
            draw.text((640, 600), display_title, font=font_title,
                       fill=(255, 255, 255, 235), anchor="mm")

        font_tag = load_font_fn(26)
        draw.text((640, 660), "#PUL7SAR", font=font_tag, fill=(0, 112, 255, 230), anchor="mm")

    if os.path.exists(logo_path):
        try:
            logo = Image.open(logo_path).convert("RGBA")
            logo_w = 160
            ratio = logo_w / logo.size[0]
            logo = logo.resize((logo_w, int(logo.size[1] * ratio)), Image.Resampling.LANCZOS)
            canvas.paste(logo, (24, 24), logo)
        except Exception:
            pass

    return canvas
