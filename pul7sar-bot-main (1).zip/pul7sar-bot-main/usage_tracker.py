# -*- coding: utf-8 -*-
"""
==============================================================================
Usage Tracker — عداد حصة يومي آمن للخدمات الخارجية (Groq / Google CSE / Gemini)
==============================================================================
بعد تسريع الجدولة من كل 6 ساعات إلى كل 15 دقيقة، أصبح احتمال بلوغ أي حد
مجاني يومي (Google CSE: 100 استعلام/يوم رسمياً، Gemini: ~500 طلب/يوم رسمياً)
حقيقياً وليس نظرياً فقط. بلا هذا التتبّع، تجاوز الحد يظهر كخطأ 429 مفاجئ
منتصف معالجة خبر، بدل تجنّبه بهدوء من البداية.

الملف usage_quota.json بنفس فلسفة posted_history.json تماماً: محلي + يُدفَع
لـGit عبر git_commit_and_push() في main.py (وإلا كان سيُصفَّر كل تشغيلة لأن
عمال GitHub Actions حاويات جديدة تماماً بلا أي حالة محفوظة بين التشغيلات).

الحدود الافتراضية أقل من الحد الرسمي بهامش أمان (95 بدل 100، 450 بدل 500)
لتفادي حافة السكين بالضبط، وقابلة للتعديل عبر متغيرات بيئة.
"""

import json
import logging
import os
from datetime import datetime, timezone

LOG = logging.getLogger("pul7sar.usage")

USAGE_FILE = os.environ.get("USAGE_QUOTA_FILE", "usage_quota.json")

DEFAULT_LIMITS = {
    "groq": int(os.environ.get("GROQ_DAILY_LIMIT", "1000")),
    "google_cse": int(os.environ.get("GOOGLE_CSE_DAILY_LIMIT", "95")),
    "gemini": int(os.environ.get("GEMINI_DAILY_LIMIT", "450")),
}


def _today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")


def _load() -> dict:
    if os.path.exists(USAGE_FILE):
        try:
            with open(USAGE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and data.get("date") == _today():
                data.setdefault("counts", {})
                return data
        except (json.JSONDecodeError, OSError) as exc:
            LOG.warning("تعذّر قراءة ملف تتبّع الحصة، سيبدأ عداد جديد: %s", exc)
    # يوم جديد أو ملف غير موجود/تالف -> عداد صفري جديد (هذا هو "التصفير اليومي")
    return {"date": _today(), "counts": {}}


def _save(data: dict):
    try:
        with open(USAGE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except OSError as exc:
        LOG.warning("تعذّر حفظ ملف تتبّع الحصة: %s", exc)


def has_quota(service: str) -> bool:
    """
    يُستدعى *قبل* أي محاولة نداء فعلي للخدمة. عند عدم وجود حد معرَّف للخدمة
    (اسم غير معروف) يُعتبر بلا سقف احترازياً حتى لا نعطّل خدمة بالخطأ.
    """
    limit = DEFAULT_LIMITS.get(service)
    if limit is None:
        return True
    data = _load()
    used = data["counts"].get(service, 0)
    if used >= limit:
        LOG.warning(
            "⛔ بلوغ الحد اليومي الآمن لخدمة '%s' (%d/%d) -- سيتم تخطي استدعاءاتها حتى تصفير الغد",
            service, used, limit,
        )
        return False
    return True


def record_call(service: str) -> int:
    """يُستدعى مباشرة قبل كل نداء HTTP فعلي واحد (وليس لكل دالة منطقية عليا،
    كي يعكس العدد الحقيقي للطلبات المُرسَلة فعلاً حتى مع تكرار المحاولات)."""
    data = _load()
    data["counts"][service] = data["counts"].get(service, 0) + 1
    _save(data)
    return data["counts"][service]
