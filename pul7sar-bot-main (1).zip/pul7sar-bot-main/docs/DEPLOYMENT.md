# دليل الرفع والتشغيل على GitHub

## 1) إنشاء المستودع

1. سجّل دخول إلى GitHub، ثم "New repository".
2. اسم المستودع: `pul7sar-bot` (أو أي اسم -- لا يؤثر على الكود).
3. اجعله **Private** (يحتوي مفاتيح حساسة لاحقاً كـ Secrets، لكن الكود نفسه
   لا يحتوي أي مفتاح مباشرة، فالخصوصية اختيارية وليست إلزامية أمنياً).
4. لا تُفعّل "Add a README" (سيتعارض مع الرفع اليدوي أدناه).

## 2) رفع الكود

### الطريقة الأسهل (بدون سطر أوامر)
1. افتح المستودع الفارغ على GitHub → "uploading an existing file".
2. فُك ضغط هذا الملف على جهازك، واسحب **محتويات** مجلد `pul7sar-bot-main/`
   (وليس المجلد نفسه) إلى صفحة الرفع.
3. اكتب رسالة commit مثل "initial commit" واضغط "Commit changes".

### الطريقة عبر سطر الأوامر (لو عندك Git مثبَّت)
```bash
unzip pul7sar-bot-main.zip
cd pul7sar-bot-main
git init
git add .
git commit -m "initial commit"
git branch -M main
git remote add origin https://github.com/<اسم-المستخدم>/pul7sar-bot.git
git push -u origin main
```

## 3) إضافة المفاتيح السرية (Secrets)

من المستودع: **Settings → Secrets and variables → Actions → New repository secret**.
أضف كل مفتاح على حدة (الاسم بالضبط، القيمة من حسابك الخاص):

| اسم الـ Secret | من أين تجيبه |
|---|---|
| `GROQ_API_KEY` | [console.groq.com](https://console.groq.com) |
| `TELEGRAM_BOT_TOKEN` | من BotFather على تليجرام |
| `TELEGRAM_CHAT_ID` | معرّف القناة/المجموعة (يبدأ عادة بـ `-100`) |
| `GOOGLE_API_KEY` | Google Cloud Console (Custom Search API) |
| `GOOGLE_CSE_CX` | معرّف محرك البحث المخصّص (Programmable Search Engine) |
| `GEMINI_API_KEY` | [aistudio.google.com](https://aistudio.google.com) -- **مجاني** |

`GEMINI_API_KEY` وحده الجديد في هذه النسخة. باقي المفاتيح لو كنت مفعّلها
بمستودعك القديم، انسخها بالقيم نفسها.

## 4) التحقق من `logo.png`

تأكد أن `logo.png` (شعار PUL7SAR الحقيقي) موجود في جذر المستودع بعد الرفع --
هذا الملف لا يُنشأ تلقائياً، ولازم يكون هو نفسه المستخدم بحسابك سابقاً حتى لا
يتغيّر شكل العلامة التجارية.

## 5) تفعيل GitHub Actions

1. تبويب **Actions** بالمستودع → لو ظهرت رسالة تفعيل، اضغط "I understand my
   workflows, go ahead and enable them".
2. هتلاقي workflow اسمه **PUL7SAR Bot** — ده الأساسي، مجدول كل 15 دقيقة تلقائياً.

## 6) تجربة أولى يدوية (قبل انتظار الجدولة)

1. من تبويب Actions → اختر "PUL7SAR Bot" من القائمة الجانبية.
2. زرار **"Run workflow"** (أعلى يمين) → Run workflow.
3. تابع الـlog مباشرة (اضغط على التشغيلة الجارية) للتأكد من عدم وجود أخطاء
   (مفتاح ناقص، توكن تليجرام غلط، إلخ).
4. لو نجحت، هتلاقي رسالة نُشرت فعلياً على قناة تليجرام.

## 7) تفعيل ميزات Gemini تدريجياً (اختياري لكن مُوصى به)

كلها معطّلة افتراضياً. عدّل `.github/workflows/pul7sar.yml` (من واجهة GitHub
مباشرة: افتح الملف → قلم التعديل ✏️ → عدّل → Commit) وغيّر أياً مما يلي من
`'false'` إلى `'true'`، وشغّل التشغيلة اليدوية بعد كل تفعيل للتأكد أولاً بأول:

```yaml
USE_GEMINI_IMAGE_VALIDATION: 'true'   # تحقق بصري من كل صورة قبل قبولها
USE_GEMINI_AI_FALLBACK: 'true'        # خلفية بديلة مولّدة عند غياب صورة حقيقية
USE_GEMINI_FACT_GUARD: 'true'         # حجب الأخبار المتعارضة واقعياً/زمنياً
```

راجع `docs/GEMINI_INTEGRATION.md` لتفاصيل كل ميزة وحدودها.

## 8) المراقبة الدورية (أسبوعياً مثلاً)

- **Actions tab**: أي تشغيلة فاشلة (❌ أحمر) تحتاج مراجعة فورية -- أهم سبب
  متوقّع هو فشل `git push` المتكرر (راجع `docs/GEMINI_INTEGRATION.md`).
- **`blocked_articles.json`** بجذر المستودع: راجعه من وقت لآخر للتأكد إن
  `fact_guard` مش بيحجب أخباراً صحيحة غلط.
- **`usage_quota.json`**: لمتابعة مدى قرب استهلاكك اليومي من الحدود المجانية.

## استكشاف أخطاء شائعة

| المشكلة | السبب الأرجح |
|---|---|
| التشغيلة فشلت فوراً بأول خطوة | مفتاح ناقص في Secrets -- راجع الأسماء حرفياً |
| لا نشر رغم نجاح التشغيلة | لا أخبار جديدة مطابقة، أو كلها بأولوية أقل من 20 |
| فشل `git push` متكرر | تحقق من صلاحيات Actions: Settings → Actions → General → "Workflow permissions" يجب أن تكون **Read and write permissions** |
| صور غريبة/بطاقة احتياطية دائماً | راجع مصادر الصور (TheSportsDB/Google) شغالة، أو أن `USE_GEMINI_IMAGE_VALIDATION` مش رافض كل حاجة غلط |
